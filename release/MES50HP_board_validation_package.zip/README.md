# MES50HP 直接上板验证包

这是可直接交给板卡验证人员的工程包，目标器件为 Logos `PGL50H-6IFBG484`，时钟为 `P20` 50 MHz，UART 为 `R8/R9`、115200 8N1。

也可以直接分发上级目录中的 `MES50HP_board_validation_package.zip`；解压后保持本目录层级不变。

## 1. 下载 bitstream

先在 PDS Programmer 中选择对应文件夹下的 `.sbit`，连接 MES50HP 的 JTAG 并下载：

| 场景 | 文件 | 现场行为 |
|---|---|---|
| Pipeline SoC | `bitstreams/pipeline_soc.sbit` | 基础流水线 SoC、UART/GPIO/性能寄存器 |
| CoreMark 正式 | `bitstreams/coremark_stable.sbit` | UART 等待 `R` 后运行 CoreMark |
| CoreMark DebugCore | `bitstreams/coremark_debug_ila.sbit` | Fabric Debugger 中出现 `coremark_ila` |
| Logic Analyzer P0 | `bitstreams/logic_analyzer_p0.sbit` | LED=0x5A，UART 输出 `LA_READY` |

下载前可核对 `bitstreams.json` 中的大小和 SHA-256。

## 2. PDS 工程文件

四个可重新打开的工程位于 `projects/`。请保持本目录层级不变后打开：

- `projects/task26_pipeline_soc/impl.pds` 或 `task26_generated.pds`
- `projects/task28_coremark/task28_generated.pds`
- `projects/task29_coremark_ila/task29_coremark_ila.pds`
- `projects/task30_logic_analyzer/task30_generated.pds`

对应的 `constraints/`、顶层 `rtl/`、Task 29 DebugCore IP 源码、PDS recipe、已生成 `.sbit/.smsk` 和时序报告均已保留。若需要重新综合，从各工程目录运行 `pds_recipe.tcl`；共享 CPU 源码位于本包根目录的 `rtl/`。

## 3. PyUI 与现场脚本

`pyui/pyUI.py` 是 Tkinter 图形界面：先下载 bitstream，再选择 CP2102 的 COM 号，点击 CoreMark 或“逻辑分析仪四模式”。它会把 UART 原始日志、JSON 摘要和 VCD 文件写入输出目录。

首次运行若缺少串口库，在本目录执行：

```powershell
python -m pip install -r pyui/pyUI_requirements.txt
python pyui/pyUI.py
```

无图形界面时可直接使用 `pyui/coremark_serial.py` 和 `pyui/logic_analyzer_serial.py`；完整管脚、跳线、验收顺序见 `docs/reproduction.md` 和 `docs/field_recovery_card.md`。

交接前可在仓库根目录运行 `./scripts/audit_board_validation_package.ps1`，或在本目录运行 `./audit_board_validation_package.ps1`，它会检查四份 bitstream 哈希、Python 语法和四个 PDS recipe 的全部源文件引用。

## 4. 推荐答辩演示顺序

1. **最终应用（主段，约 2～3 分钟）**：下载 `logic_analyzer_p0.sbit`，按 `docs/reproduction.md` 将 J8-3..10 分别接到 PMOD J12-1..8，启动 PyUI，依次运行 static、counter、UART、SPI。展示 LED=0x5A、`LA_READY`、触发位置、解析字节和导出的 VCD。
2. **CPU 性能（可选，约 1 分钟）**：换下 bitstream，下载 `coremark_stable.sbit`，在 PyUI 选择 CoreMark，运行后展示三个官方 CRC、iterations、ticks、score 和性能计数器。
3. **流水线调试（可选，约 1 分钟）**：下载 `coremark_debug_ila.sbit`，在 Fabric Debugger 选择 `coremark_ila`，用退休事件触发并展示 Stall/Branch/Flush 波形；这一段不使用 PyUI，也不把 DebugCore 资源计入正式 CoreMark 指标。

不需要同时打开四个 PDS 工程；演示主线只需 Task30 工程 + `logic_analyzer_p0.sbit` + PyUI。

实体板输出必须保存为原始日志/JSON/VCD；仿真和 PDS 估算不能替代实体结果。
