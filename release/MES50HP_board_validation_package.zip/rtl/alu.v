module alu(
    input signed [31:0] a,
    input signed [31:0] b,
    input  [3:0]  alu_ctrl,
    output reg [31:0] result
);
always@(*)begin
    case(alu_ctrl)
    4'b0000:result=a+b;//ADD
    4'b0001:result=a-b;//SUB
    4'b0010:result=a&b;//AND
    4'b0011:result=a|b;//OR
    4'b0100:result=a^b;//XOR
    4'b0101:result=a<<b[4:0];//SLL
    4'b0110:result=a>>b[4:0];//SRL
    4'b0111:result=a>>>b[4:0];//SRA
    4'b1000:result=(a<b)?32'd1:32'd0;//SLT
    4'b1001:result=({1'b0,a}<{1'b0,b})?32'd1:32'd0;//SLTU
    default:result=0;
    endcase
end
endmodule
