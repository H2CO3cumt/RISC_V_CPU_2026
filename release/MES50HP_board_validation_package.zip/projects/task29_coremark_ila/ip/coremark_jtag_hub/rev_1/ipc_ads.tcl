# Generated at 2026-09-15 21:51

set_arch -family Logos -device PGL50H -package FBG484 -speedgrade -6
add_design "D:/RISC_V_CPU_2026/fpga/task29_coremark_ila/ip/coremark_jtag_hub/rtl/ips_jtag_hub_v1_5.v"
add_design "D:/RISC_V_CPU_2026/fpga/task29_coremark_ila/ip/coremark_jtag_hub/coremark_jtag_hub.v"
compile -top_module coremark_jtag_hub
synthesize -ads
