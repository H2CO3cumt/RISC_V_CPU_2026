//////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2014 PANGO MICROSYSTEMS, INC
// ALL RIGHTS REVERVED.
//
// THE SOURCE CODE CONTAINED HEREIN IS PROPRIETARY TO PANGO MICROSYSTEMS, INC.
// IT SHALL NOT BE REPRODUCED OR DISCLOSED IN WHOLE OR IN PART OR USED BY
// PARTIES WITHOUT WRITTEN AUTHORIZATION FROM THE OWNER.
//
//////////////////////////////////////////////////////////////////////////////
//the jtag_hub module, it controls to select which debug_core and sub module
//note that one FPGA only support one jtag_hub
//
module ips_jtag_hub_v1_5
 #(
   parameter  CTRL_PORT_NUM = 1,     //@IPC int 1,15           //the number of usr_app connect with jtag_hub
   parameter  UJTAG_SEL     = 0      //1:use jtagif ;0:use scanchain
 )
 (
   // for JTAG_interface                        
   input            tdi_in,                    //TDI for user data register;
   output           tdo_out,                   //TDO for user data register 
   input            reset_dr,	                 //active high reset when TAP state in e_TEST_LOGIC_RESET state
   input            shift_in,	                 //TAP state in e_SHIFT_DR
   input            update_in,                 //TAP state in e_UPDATE_DR
   input            capture_in,                //TAP state in e_CAPTURE_DR
   input            sel_in,                    //user data register is selected
   input            drck_in,                   //TCK for user data register
   input            h_rstn ,                   //hw reset from user logic device, active low.    
  // for user_app interface(debug_core,etc)
   output           drck_o,                    //transfer TCK to each user_app
   output           conf_tdi,                  //transfer TDI to each user_app
   output reg [15:0]conf_sel,                  //select config module which indicated by ID  
   output reg [4:0] id_o,                      //ID number indication
   output           capt_o,                    //capture
   output           shift_d,                    //shift_in delay 1 clk
   input     [15:0] hub_tdo                    //read back signal from each user_app

 );  
`pragma protect begin_protected
`pragma protect version=1
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="Synplify encryptP1735.pl"
`pragma protect encrypt_agent_info="Synplify encryptP1735.pl Version 1.1"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="Synplicity", key_keyname="SYNP22_1", key_method="rsa"
`pragma protect key_block
k/HD8wTGkajjsgrtA+JwYwjaktcYNZ9xDCXNe+Kglxhcg2TTOHyTqStZIAVUZmppiSt6twrdEqx8
qHsvguLOtpAdzVMVfoWb3QtAMGktt4rlKW/LbR+5OIMD2aR58ezm1tx0oBlEWEe1+thbJymL3xwE
qv/VRFf2mIlihrQ6ByW3diDqc/DqpHem17q3u+TMbxUTO9+vmhS4sSEFKNnAb8dIZtK8SuQrJxCw
ugWJVu2U+CGLVDwroKq9NvmsHg2rtVYACc9T6mwTXEf8YikCe8D+q+QjbbDZzH29zavo5WWZiiKl
ZDJnnlNOnAK+tlrE3/1473pAhfw2XLeu7saipA==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="Pango Microsystems", key_keyname="PANGO_24", key_method="rsa"
`pragma protect key_block
JAPZKvN/GbZuajP7015wR7R930oMfcq5a/tzBclu6hl47sKNxmL4o207aSvhlqDDO7Jz71WOzTKx
knIRGAgqm+gHQ/ZOWO2XT0mFr044ZFPxaA/luEKcfcrCi/b3V/raCYRwiOL+IXA4yA5SG7A38YvY
1zxisABkOQz0LZy+u66cu1GxdruGEMtnagqPO+DBymjf09TFwRM+a6qLfBujT22IqYm6mZt++1Be
BLKJAYvmbquM83yFlPjpINGyrqN9Wu0CzKZ/5fmHg8CD6hly/46WCHmRpFcN11VssyQ7hXcH3avk
7SfjrDZvk6xIn4aG+xY5goVwuhFtKtg11W4lwQ==

`pragma protect data_method="aes128-cbc"
`pragma protect encoding=(enctype="base64", line_length=76, bytes=11088)
`pragma protect data_block
ObY1LRmniyxBxVvvfNLJDH6/Q4RugM38Un75DuAk80Bi381og58T3xACbvspa89Qbgdf3UZ3W+90
4oZq+PgwQXXEF1IX2lQTKCeTg6xBzaguZ2OrO4nArNd2ndqFkCOA2y2nteLtqU60MUZQ/SmlxrpJ
EySeGgeExAcysXRI3MH8XPoHFMX+HT9i9G+VfRW3T7NeUrZYSPFjLRjpov3XLUQyjhIGFs5s1Bv4
uU4ygpO+TN54/eiP99z969JPDYmzELXV3hGYWk9/p04LWpDJZsLFKN5k7pEILw02DDf6KSX2w2bV
XH7y0lOl465CLkFQT5m3BrprsEWK9FJLZi38ah5v0IKiTv+fdNC376HiCXFQO5LuppMy5T+GHx2e
59/kGUAssK+TkyOqa4w4B5Ty0YxA7TN79PjdAPGyburCgtc/LC4OqRCEWtDGx1tijyDinngMcc6C
DA3Z+BDaffk11RGszoOR4EYGpsZu72zCJxPAs1iBL5GsSX+Scw58kHli9QNMq7SjlPsmF89UULht
A7uzFr0t2eY+kcxvw1nkAUN8aigqwl4ErxFjKpQ+mm1H5C0wWp45emt4TEDZ6wQlsjQJaxJkF3uN
ddNAtwzUcz+M3n89wFe3V0LvUOkgd0ZrnLsQu4B6p3K0QXZlITGLz6NAjHxx4o51GM+fC3oVqg7r
12QH6/1MxLlV/oHxTsk1hQD3TpGx4H+K2v+C2sfW9nkUK/7+O7HfmbxY6Ga+0pEKuSJZjRT6D8kj
ckOLXsn1P0SzPM2ztdMDMDRapJto18kky6WkP5L0rseTkl+PE+OkU6JqK3deaKEyYo4cMUH4DYrJ
DtzqmnwyjJh1TaJQLOytdpG3R9HCIgyD2m2E8qIbIWK5U978vQqoq8xICQLvwvBw9VtQxDtYFXby
lITE4jcsweep396WNWSBxvmPiK22HVzTv5c6ki3uldz2EtiqB77kvEz5dtN4zWpIL6cYPHKT1aJI
qAJeXsqhaVcBlspHCilRZJNIcd6CAOB9nK4qVypShgTXeQzKBlCifbVd44L3+LY845JpaRfCL335
BmhaBqIRCfOL0uXNyv6PkfJhwfxCl4CrGylvIEsQENezYDkZD5gFIaS19IufSCOWirnIEo30Q08K
XlzCn7ZzLmMaD0VSIfCiK983TNwt8iz+kUhHjdQj2KxRl0fhG8XZmlfWbKIx7ChH3f04vllayBOu
DAFqPGkQPjHfXkUPvPi+Plxc7xRInkLC3BvJeoDnqZEfIhynjZOLTO8utKHNbtkOKiQjhR65m6lq
ZbgK+QVtLhcZZdMB6JTyCPEfu12Ebm099vx9b2ObPUlzpvuu3wqB+r1x9FCKWiHUvxuBWl+xMxiQ
iwGp6eUNY8GwJyknlmT8JDEoSwzPh2aqCrZ0ZkEs+3j/139EESIrj3e4SlwwYC2/fuocV4pUonVq
l/M60JZAxPwb+OmCIdCCwpsxIBH2ThyZ+cPrmxJ55X1eOZrqoZLTfOoK8hwt7myiqotwhGQ5wrKY
DlXaiFOQxxtCSxUuyvDBJuZEpot78Ss/HyLGdGXgIs5lCruDxz9fPwmOzUtauql52DDcfYEbGxg8
th18wDnlPGOGE4SbbfjYG9bDSxvlXFcfU1QRmGhWACT3WBY3zuLu4ClwNuvNfKjBStChWOXZhv/L
I95Yob3eyK60nPEDMEdDr/dQ/mHU/oVqLn+rHZG1l9DEul7ghL+yvvijfgyGAzkCOZ9ZumFJQes+
hyobwiMZwyodAN7XipBfym5uNlGCqT6pSjAKrjdjNWy6xVy4GmLDsNfWTsTzHST9lxD3IGw7LrGm
v3Ox5V6HRQiicUy/LwKcPrKKavO7pO7GQPe/xkr3868FUAdfS6QJYd+7Ffd4HulC6y/vecb1kKjJ
k9nCKgNfzr28P+z/02kuKyJ25TpWnUFykgL0spvOf9Uit1z2cQ5XsbIN5tEDxLy8mGgrgWc2ea5P
QE4BBbePCZkwL+GXx8QsW1QBZceECK6BBqKNNW4ZQ7vbCX6q6037FeeKMbZM3ja6M0N2WHe7V/Rs
Ejla0m0TIA7H5l9k46GMD2VdEBpT9yKXXb7hVUbZMyn74KIjDpb2E+q5eD97/Sh9/HPXuNPSHlKD
zsg66Iphsf1WymzHkZCTZG+9ymLow2NrzRJ6a5O3TTb72LjEXTrGb2Ubw6lE3BvjR+LLPanrQtnO
CLiecgk2WVOcQq321F74kV4TV6yjI2kDrG0rGZaHb8PqlToeyC/iTw1p2SRfgz7OX03Lc4Xj9ltZ
acN8RJvx0oZqbfZDlN6ecr4uP8Ad6TnnA1bdkX51Sr/Sulk8ktJGvL7BShJZtbbq0f80vwNiKIcD
I7jYSw0dlJPc6CrfnO2H5/KUQalNTje8ilA4sYDyIq1ryDa8lvSZoOh5klAFC+T9Fyv6saXxccpp
IebGEUGwho4PP03yFWFGwLjJnEJ9HMwgpsRe1e0pwOxA1xgqVwkyfXpqCnMtSh4/AkaDfXHvl4JK
R5G3PnKv5lBI5+xh/P7GXjb3XymYRslhoKKwvufs+eBymLVZNvbMaegyrOKvmmzgLZorZ5xX5dop
DD2OdSx/f9z0cOE11MPABblD3/sH0qQ+qDuM4/ZFoHjScX3f9d6W7H3imulc148thFJe+mm75Zzy
c3zmjmn8qIuJ5k4HN9jH6gMTgCxIKHaFsz5wlSrFmSHd+MFu5ryMIG2/MO0PAvcDZdH15XjQpy/L
gimFTcljG6ibBv7+MLeioll1T0A6Hq6baekH4Cy9ex6TLL1HBhhOjmUxZrha5EE0TlxwhY5TOxGF
5fmiAEURpj5cZT5b0J1f9BakCZLrocUESsRelWEqitYIp9Ge6B3iIgovlGsXdJGuIJ8Pnn4BDSOn
hTqOWYLh/MQTxzJgUo51QkkCRrkwQkh+FQ83N1fsltghsBf3Gj20elWnpUTQjafZvI3MTFocg1JG
tVNKAHvhlEd7R4avPAo2HAh4q3u+GmVzkQFsqqDTKaWt7jjJf49PmLHFpBfC6B6Z1iO+0uVCoiEt
2f1Co2255Xbn8xioV5i101lcfIGRG56WjkIWrXU05pjKPSne3t7M7ORUtOCQZP2bEPJalpSmDwM/
dyfma3XivVPN6Hya5vlDslVfU/SApoar08jEd2ttvPLe4EhUks8sTKAk3YLWD3WtheG4B8BycUIO
l22h+nKQDegg1g6BXBsDG1FtuXnO0ffMS3+UwGaM2yR7TSINo/yE8zdwgxrYqU3E9WHZU5Ibz1Sp
uV/YDsG+594SYj+KxmJDtqTbcDX4j5TvkHYDh19E7ukKtBi16czOYksWgAAdkSTpw5MIX4YetBlf
YJxGc5xGxr0vsTpeg1HzSpOW9WbQPSvVmlJWmefAxjWRZhiaK47ELbysZGe/UEzl734Dlj0xXMaU
zCql0kTLUUfSbjBbvvWw6dDmhVf3gDU//tSzaPkyA/UgQMnNU4/vgSc5Wv4bCMw2sHUHBhww135w
AG5VWpHABR4pusKoybfy5vC401rRmS501DJMT7kwoWojXWUEOkHoHA8qZCc4HWT2G5soieaHtaEy
ezalrwNgBeyC2cg50rQHHf2LY47ooMH6WoxXKifQBjmPD6w8Y1kz8U4is3zDhvUpF1PW2r7styuV
v+E63FlRYj+GFqGxSzMaks8qraHZ6j/t3fsjUcSroE4pNER6A9ZHpb8thMFrx0nBx/k+6EhtFHtf
EVhRlHBQIXIh68OweW/HvhM4ccCVN+oFvu5WJ4ZPCbrLb2DoufV/mr2S8OSbWLJGFUekDVco+7jq
0OeopdZxjlPUTIBrYCquvS62wkEuy+dIGo0jAc6yLVZfNbL8gbY/v0wJ9FjbzhOWzlGQ6frqVoH9
x08ipR7uX0TFGwG0KJDeVMGVuFoz5v976hMHKqpL1Nb8NB00kqjWzwPwN5yZqvcA9ukkAJTzhIqQ
uHXTMMbUULbPSIZIlj8T/weR8JYLH8HPA4W0J8MtiLT5ogToYMqcuxp+GtlOnrD5hVXUS0iVL7H4
bQVP31ESzeP9OAjOthBlLoLpeUn28DbFYEAtbmyNyYYAqBGbr1/bAyU4RFqK13BG7hhNICDZvajy
nP19AVSJ3Mf5nE/i+eyDEGUTDL8yA29hjkZnf0Q4Cf1+Y1nHqUX5vt4zqjUbNjJmxfKrVwmkkDdh
k/wqFlfBPnGjCen+eq00tIgCI4XmYjDtGdqx5qnLm0AYR+4XbGOWDpq9LT3cZXFPvNUkBb+Ubq4x
U3yYneoSzichq2IAvFUoZcckcv38UXkFYlB2k2+PIrvNAUUgZOW89/6Mo6OXOaPcO5JNFXd/s98n
25TFm//U7orQe0pXqu0RlgcFsTZwrxOvi1IRVGQIv8PfkvrDm/3FN86o5xkF5gY3/Il7+3sd/7SF
OUWiZil2EPtApIwuqVfXi7483Dbh4s2fCfOZnMiZE6+0F29a8r6yoLlCrCU3oFo7qPOczM9HezIU
67jNqeYK93cPDPI3nhK10ZeIOPnTMqq8DWnKbMMW2URqDOjIsCJ/O5zD4d4wyg+NFNrIOIICXa7W
j92qYAyy959FP2QmDUlmxl2mM+by1AVZLS/f/rGfoQehnE37uz3rkh+10IKKjhfQpD+SZ39vsvKx
9lwwajY5yTa7VkvoFLFYA28BJ4XomKG+4pTAYSOqqpw2b8kkaKQfN3zPu6a3PvqvouHbeV0r9S7I
jPwdg4L+xgCBR7Gt/t73jdXpb7dlMnKeUKCD0bsuBs/61wlABTYUK9i6x+075Gm13gCHxmGXqXQ8
fzGGJ39QSA9id9BFGEKLV+bZx3u9DhAgxecqSxvvzxdYPuUoiHJ9ib7KjUH7+3xUgo4u+oFq0U07
I2f+A1xrBr2Mx9deCkIQunFroLXEL77tiy8/Ulmo4htJp0GwRqS1rjVZtd3LvdUfL0YTaa4ud979
j+ZEpaKLavBJvBty7SNVf4UzKEqJ15hClldiIz//5UeZLETIJUQw+abtxYYZu1tvENpHWxSQv1li
mS8VWM5KEArGvX5rYU8C1B+QeMOHT0Wgp89GWJWjiD45USMFBoqYCh4hkNJBc978VbINy5lsiKNA
OpdZGQ1bBEKnCHCpDxsmNpGd4b46yN26Gz1oW9Q3n2MJ3gaHS7mjw51gyyi+qaGveU3yoLqcPUYc
AKr6xrb2y0z3vSXu3gviRuw2mTpgimV5yK/LrdZpjeBbxYOUSvWSx2fOgZF0k03h5S3O6wzPztvR
MLoDgE3nzCzPySlNtgh8BHE6TJW9zqF1PMLHK0eGHXp9lOneXCWozMlaTduzi5PMWgC5E6+XrF/J
SBblR9hY2cVABvHAbYyOEcDTkLGyy4gVWVNLnaqq8773uTOro1Z4+ocJhkZYQLKJWXipJkxKBmPH
VfBI8f5YX0nySt6wWQaHJXQi7ppeMlXMT+AYLtZl1rze+ebBKfdYyFKxmqNUZzi9vvIHGRW/+Xi8
B8cXnlRgLdlPxCFy+bAd6ZgeEUNkaq+w1z2MQ8khi/uAsdsCcjJfBd+2M3lNu/fGIqaJeiYWZM7E
Ji2IzgIuqdtSNN1hwvIxPH1yhUwtmpvY8IRcp/uixfxau+UVGzVy56lEMLj3cYAYFL+9DaawGX9z
QDu0t/GoltqDbzBCCO2JByF/ab2ffX/cN7qPOT0HYFVDZcXh0P7neFI2AXqgOY+4dJPvvZhG6EWN
yBCEoy49HRjiqfrsrSmJU6KCis91HV+f5nEhBpZQPUscrwd62XdJAbF1u39g4kXUHQg1JIMvfNVo
glvjIuhxDLsaxyimTXah8faB8btOk43JbwlOkTHgBd6GNJojIjjbCiiSNCQ+X8DNEocqHmVFCtwe
uHdckZ6vpFpt2rOPL/WPCmNxHjwrRFZIHPcFwWNdCW7gfmiwDsYJwvpgz7tRIOzvERfpCnk9iIB8
9PokWXT12OZLjBq4cJe/jq6SoBcJ3z/Wou0YgiBlIRmm6qrhn90e7lWWO0EcyOxUqqbshGto8cgg
e4e91b4cGJo2V8fZ2HE/4y/myp70rOBQJD5y6SLhzie5Kf5oGdkvZtjx+nftmAFOKCfNGZv9vEMz
x5sC6hjmnZbKp0t+LLeHjEiBtXHxrDNWogRArk/1l4bESfxSkvZe7U/mrSPIhQX8BL9mmHsxVRoV
//IG0XuHTyCTkM3sdlFF7SsJ0Xqv6Z+B+DjMcOW5MnnqNZENQ1ydfstj1ot/AbpNT8lcHzd03dly
KOSyOcRbE/TdigoQXI+ffUxoRfxEtBxm9Y8N09R7/pZgoQP+XKuJxwD7Kc/7YrSqnRbOOeqdfu97
RXLvUOBfMnsX3uJuU1cmjyHeSAYPHjZgu8LfoA/IA2XGvjUal8UBpghZqa6DgNFhRGPCb9D6WbZY
PLYn3W2GsdSvYa707R7jkK69trFgFPvx5ETSasJDWypIxbO/+GCvG9bJqLEwUl02g7Et+Ax7hRe8
i+hsrwsq8809vNYa9YvbhHiXCGOr+CtpfVWKOHa1OTQPPeWJtvbWgJd/xpdppOR5sT4VwsdB53ht
uZtlpuKDEZ9pjetwkKA9b3JghPCLkVFHxE/q4jk1lub621hvhDJAjUfYlDGcnby+ial20HG9262P
whScILE0lxLBzH0jTaKLPHf7f7NQQHXmN9Eii/odrZwwTGSj0todJgrSQKklqVgaRu2Igul3I8kW
zW7/uWFpuSonSsVmMEf3tujqEGFztaph62SD+BfjLyv/gtcULe8ACu26ik2GqboPwwrv2Za4Weg/
6s5IFGnTTeaWZYYfhgtimeIFIXxtc0hG1cIJCoT174C7j+74VaBusbjy9UDC3zGGggnyDNf0ryEe
wzhgXpXNm2jk49/oqX+UkbZNJOOu4EAbaGf0wCkxUQlUTJ+L5f54GhnefHnbt47ipXpIh3F401NF
EtK9BvRR5nKWlWKD70dVORSqfgEvwNC6p7AjwZaB9/XSvew7zFRyHYu1FUYQzGpRHXzcUmkeEHrv
If5Kg1JYORP/JLwJcDu3hCcvvA36fri919NFxjvS2OyXeHCjOosIXHtQn8UrkmjeduYNJXygXH2F
bUku1aXZTVfEHzN2kvpRq23F5BtqxiJ/oUK1IGJHmgNeaHMFabAyvGIXGpEs+QyqV4U6I7rUemjO
nNG9ABXugNlBKxeAt3UEL+DiIggCwHNhfVxc+PNO6G6mPeGqGKoDoWyXG78/EBDUILhcxJeT/u+J
pS3RfELix1ozU81C8YlyYSmj0UPWppmRjccMXEQh7JvzWvDucPTBblEKGEcn4EEmU4WBHf6r+kRm
FUG4XVUlbunFXeAbDW+e0NhH1VQ5ts3kppdHAAFOMGNCY13Cc/sqR2TpCTGrDVByhEAXXLNDdJao
HPBMu3LMv38zvorPg4DfvkibvFkxhZFrrSRrIZu24gehqfwm+rWX8X959rHlZnk56nI52lQnhIpV
Mg2reYTTGf++UvU3Ij76OxzaZICqZwZosFN3axrtrJoUQXoMcYkIUtB0ehBQyjGGAfAIWfHSPkP9
xQ1bOGQVdtN8exr/MVcDOs7hdPS/Z0IxyxcGPp+8xek1ML89Tyz7yG3wrvHJHYt3iLvUYp+hFP4t
4bbQaq4L5g0CpUfbQ0OK0nPyNfwxmBPDkOEyyrv/a0Sze/21ooSHjIEllbDthHAUQyYBu42K5fLw
NovFf2x910hwRYxw+ZYnUI9Mvqn4BC3SpeTOQ3Enpc5196CiJs+2Qb3Ec34pJX37hv0SftyornkE
XMxN55Wxb4u5QhwOJ48rat/WFs9ze7tAIBgoLOuqcg+pUl7WqY3ZJMffNj/G1a4vJiuc6Ncj8ehp
cd1RXbpwz1jJVhzpimdKXAlzHsdlLWR++jS2CL7gCEh4owGv8bqxp8V0MV7CEPWWQ3ffPBRtlATy
qwuuPFheEgIcikMvkQ/ZfJjShwFOVWAm2e4SIyINzI84v9n0kN8NUlWkuEMLml/7+BXLycapZX1W
Z0jq1+n2zD5LsdQ7waVZgtbc4EoaUWiNkJg0Bx54EoD3C7iGtpvXMdrFuLmSraSDBnLgxGFSlv0v
NCaSUpqktoCDvH2UvmdMtqfoIoOf2tztQwF1CTDvklEfgS3gLwO5T36YwS2hPsA+Er+MZAEWYB3t
iHQxmqlnjNbiW18TVVjip9aHsq7H1zTRhgLUEeyOhi/TrYG17ea+LRQ19lSM05m7H5Ri9SjjXR77
TJTpr2lTdGX7WgCtpOVFT6JgpjNddDpJXu+CiQAqZGawG55pGNhEOMJpXBo6TWfxIWTPf5T80mEw
Zlcy05hGPqm673h1vEczmef0wdphwdrXqMK3fxYFbrAWA5xeilD7OcUEVUN2kjbBIGyWY52qBqoV
PVV7T6z2lBndutGXzN6K2mJQjIaoCowQIEG5TdvWpI6PjX83mXz334wPoSFsBFg1wc9f2pJCEC/T
SgvAHCIRuYWkNTcgifJT1IZ8UbtGj/FMVIQZaroKAyZz3YKxx6tGcaVLomlz9XZWmuFZBHh7kwAE
A4id15iD1O0jn7UV6jSy8u5V3kgBu3u2kMmP45OjdMX0W5XYmKup8AhG5xzl4CHH/czPv18dEIr7
DVLeOlxssXVM2oBiBOQ5fZ1SQIJSBgTo0shTgsbZcdsvO0wuQz14EemkRy1wp660KxAQCDTbzyH7
2gfEtBjyujwE6MNZh8MM8Ad88uxuu3rp8SV2k97CPnKIh+2Hv/OEsqfTlTdXkDFwjkQ+31yy6639
NfDdIdPs65gUfPXrTT/sK1RlJ+zyJxIudrChitpNgLIG4F2gCbX4GINzKI8717w0jkXY0KCoQs0h
n1GA46YCs1bIRg/vZ2LnB9F+a2bKuWl24F/Ml3ux+qk5H5Zn3v8Mxcnm3UBbJKp8l/0eiQoI2U1f
lu15rDZhzXtzmlKJWRBEv3UtVx/3NJS52hAUfHLDV52Ox6gYqrtxsZabb0BEi92KKaleAjw4+sH4
J6OXhvlZJg4seb7OEH56ls0tQRQSKzDX8HedUEI1iSUMUthyYgxqy+VAAwU0V3XfioTbEk/wJUs/
2wWhUwfLubMmCFz6TAMFPFU51KmVnxONW+7gr5sEO1nZU0kws0olnH67UWQYdNnxh7F9+MsWN0vS
QOeeroFA/RvVm9JjPLuY0PG9slSBxCcAj1BbrgB1Y+vWG09zOpLHSk2p3BrGyj2ATBcWQTiMIEy4
lpEMg0BDMV29BkG/KtK1tDrX/KCZsx3ZZS0+4UCERPOlunfw5FwwQS3e/tNZHq72q/2ep1SrkOsr
1ddOfw0kaVLoQlZp8eVUkgqQXvzjesu/ySbejnBc2NFfaSTIXL5qKvpAwq6RoDS6e6KZF/z7bc0B
G9UMF1t7Bnl1khZjO9TsMj2ECJpjxnXsvhShYeSec38zO49HfNeL9AEANXwGWqbknll8ER8aoSgs
4JXAlKUZmpIZ30lf9zd4u25F7876DECZ9H53RU6T26AbR0//2y+JplEx4MB/c2UDUNTlOdRVGKXJ
Xc5f9GMzNuCFcJTXtdsPqCcJYUL42NvgKjfwsMruq1PVqK8G4UnSEVNi6cRMMK85UZs5SKSL9jxb
n6dtVrY5xyz+aTUMSOoml1BPOmdLSv37f/9Aw972hhahChzLmrcmGasQfgqL7BgqpU3v5u9JYaSb
RfzCIxSjVV5iEfhLW4pos4etobgrtILtYACPq+OI/WLkM1guQYX84HYAKuJZDoJPb2MZMx6JQgUp
xxQhDks4qH9JtAsT62pmFiWpO5JLXBbZLLamE1BAlwHo6uqR5RaD2oiz1efUWuDFkKTH0TwWWeWU
4i2T7Ea3jO3RXglYFaMVx/hKWjrftcV3ebVjuce0WZi15DcK76QqdgxBRvJ3rbHxgzye43UyKUNR
pFGgws3FxED2ExcZHML3cO90HbCUvZdbNf30J/LDgcoahz2rOxEJ3G/6viKnoZ5EtTn3gVv2aFBp
lYqaRldRUhEp3z1/hpXmhtl4d0Hqj16CQZMpMnY7Oml2LE5rbiLr9nC4aAA+Yw/O2nu3Fo6avZ3i
8vgbafl9zGCT1loQQ/FBs4yZLwC+KLNa02qWRnjzSa0mTJv+1wNC4y8LszIC8GhwNAozFXfAE8y4
3vESDdXLB81TzbAqzIu5pkmhr0lFAl3ySfq3OaZTuCn1ux0Li53BiglxV7tOKf9lDlO8BAkO9JBI
mUIF2EvdgnvI/bxhsPFsn+xkhRZbEjdRsgyPZCT9MPfBSlb9m1WFXAPDTmbxzORZ8VFVcJK5gHa/
c9sRZFzN6pQdOxohpGsL8fCjC8Cy85IXV8qI+Qgpp2Cj1VVtFIwu01FOwhBC4k1Qb3ViwN5YB5yB
vmyJIDMC2630mEgxrdjQ6mzpWJFkbt23G0J8ZzaTr6LYZ04IZfvz68tkXxfJSKXmyTXQ+dM94NND
wrrpara1qOPN2wYwBrwCodtyxILsO+Vxc8NKBUB9QRfd8qbLhaCkS18oB+X/xHYiFYvNBjrobfzF
XWYBIEo/lv5UUpgyN2rpxMc6PEl4ul8YSHlEw7h69kcqfVBoO+Q/sSnnZb2HWID6sn6lFcGGrp02
s8dChNX0928xgQ2I6V0kjHAfWeMP3tae12nUOkPjqKKxqSxTe3eBo1hoONrXb/yklYgWy/qi5XaX
MsBADQEKJF3a9IXAdEAan4IDmqjVHEFMZlUgQRcr1vFOvpJmsRQE3sBRBzZWKXNkkXYzoEcvkamj
YmVkzjWgLNHFzcnQxdFER+cLY4tARhjnqdkHpFByLcLbDz+dvtTpZ/kjLl4CTf/qXffjAdlpoZ8c
uADcYBQUjUz8vV2PQ8qbtqK4HyVVoHtO/oOKD1oyxnU4pidzU+OGUNTeEm0FA7ooI9revIa+FBuE
CgOI6b7B9dx+PGcavx3p65Rr1XXzs0ssEdy7mn+PbjNzURtKUJ+70sF23s9ovK69tD398LYwwite
RdiFLds57i9WcOolnIwobco0bk4yGZGlAgM0KHn/NjdMqqE+lol6Wa3G7669s96pbAPoNGslg8eg
ArDMOT+NRroQPFsqdiLi8fwxkjICX3qbepMLY2NpFPmxLCbIcq/p9bbBnnAweDaRMEufcYNuVuGR
+8lr2qpNmWbzyK7vMHZ6BNi8B8vaOdha6TJgIYfxM8KAo+pA9X5a6YD6SPU6YDneR8NCWHPmSwnt
A7c6ZET3S7l4/rI9PMmlgSIn6CdnCoXcg1bqw1JWZS32Db8GClXV+i+/O8en+dOMkRm+z/setKc4
Hwkosj9vJGWq4ctiXmBT4cOmiu/GJOmh1FqCqML3zzuRpMoeeYqx+WSxJomNMGVlvK0kJj5e1Ojo
Ic4kbkfM5cDVooh67v5O97O6dl5/VadL8cHvbWPzYeLk0ySoC7NmxBWn8IRJdrMTeF7mvpHm12CS
V7yW6MshKb+T/DSTtnIBLNDgtyVEm04GdTEiIgTlCuf4q9WOF5as4DPQhv9aYdaxfrqhdtBVQNBS
WQP2WuzX26licDaTLEBi5rrYOc+cTn7CT+yzQ5vecCYF9hr1l0SMzKUwpbL3QujqmxkVtUTtEb8g
XHXNH8zfGMqnHS2d9uuHmQwsa4LDCnV4rCk4gGyrX+bHOiQhyS2J2+fp4ZPhxDr+poyNuKjKNAUc
beewTEmNrldMAKWWc10tYJPPnnw7na/Euoq58ivWBvwBgf4eT+4oMN8WWugIKumkhFv88OyrihNl
aMk50gByW+EAkR4JuOFn7mLooyRcKfOfR8cwFS3hjyXWuhBzkwjUqczm1Xfpna3Wi6F1ZHk3SThm
KhUN1sqf95BTY4wbmrzeRatS5qGMSO5vf5V1rhFvYmGorLNp74x2czBRow9W1U2ah+MH1QM5kX7Z
CcmALCNsDB/NOj8WcoEXu9ytjCvb2+zw7+cBfPC/dttFRBRGiDzWYrKLS724mXLDqrZhktH6u2Sj
2B0dgz+0oqNJaqonO8kad8lDsM2FBK1kNJYOAQ0dQDFF50SYohAF/BAi24LtiWDRiHrkwMPqjsYW
pJ2kEbgaBjDeA1gEa+EfLrT5bt+orQS9oIuHgE4g0kJ9JtrF9zY6K5881APClXMMDiJ3/eb6VgDH
L/AVjuFHdDh8bMIJ2aGxa+k5qr+91iQarCoEEsL5jzCEL8Gr48GLh0LVNphMLVMcs4HqhIfNz3we
Yfl8BhKHQ+hLnPggFjIF9oJ4nn5Tjz8V/dksmgTPFXTs0MrJLvRJEP4Gs0YQ+DnfRBi04OExSOsU
IW9CLmL2lCAZ2CYPTYZWBCDFb7s6M32qtrU+qlMpuFJnZSxy4hrGlbgHa70gCM1eF6ArBu+VAm1v
JQkkPGj7H9/1rRA3BPHDVbqh1WkOHuEU69gW/L6Zw1+psjTMK3iWBTdzntFY/q+quPx3UvFR8Q12
ud5OLljp+7714mlj0Oym4u1gZY/MkBQMX9drbG3cdktbce8FeKOUeWB0aQG/fK8eotMRl4uLY1Uc
mn6n5CuoEDIaAVfHJvAhDVqTO67Xy4nf1M+HS7XqzS34wX2FrtO0IHpYS2o0wpZSW6E8ISYD+hX8
MZjApfgeaG0YyX/ECkgr7AvFKcePeI9gmKW5P8U5yuzF/p50024ZA9fIm0S24bx8JHD5e5p6tOW/
fc49j/nK5811XZt69uN5C3Or3Y3vzN2y7xNK+9GIpdlkFUKlhxIa8LrQDg2cRWlziGctrmmJ8Xa5
WiXNunKFmYrFBn9/G9kp56sqvpx5Udm8EdBK4QRZ6Zk3k3LU+GpAJUFjIGV7RlAnjTYpoQeglCB9
eiJ4yr2Va6I+7UEVjwZiRQVZ4RdrCCradkPPDpdduKkkhZMr3b2/DxdCVb04n8rNUjjLFmU+SXHe
l+KDWLrDlnazHGFWrYR4xk/ocDTNIaXsTOiWrpfipdmPQrWhxlJ0zUf9sVQpW9xKITiJMJGqKyUY
tNmNvCW803UVPVXza4gH3k7iCZ08VJx9wm0QNLpIEmcXFVrSOMTNie5SwANytXvRa6OiIzoU8IgP
CWGHMNLze3T1B4CEfL03ohka0lERggMeLCVYY8ITzMWylHSjFvmAkA9dNR9AAqLRQHHefLkSPW/3
1VIG3Kg4zngF0awWN56L1ctwwLpZqX8v+56HC0m4h5CFSo4AtIRaFOmHAtbvZ4maaMbAo2XOjaAr
llLxL6bPyfRPRHXI0NAp1QUfEK2URv4xO4ziOeJJY4hZYKfnOV7PHy64qbR8oBuu2g9RfEunKQ9S
hRAmHkQhpWi6lfwR8ABTF5gwCMQ5tQTa901JRi1GbZhQ0ugejReEZsXXsdaZZita6LaBAKyRDLBs
ETgP6Nh8QUNF5mNpHrTNpPj6sTzjRnvkyWupTyjzXc3fiOFcC3Ea3DExVAWad8+OUrzDudfYGPtH
CbAmK1r0Bj7kY9Vm5yjjNfTJHDyeGIOYWiOGPrmpnDD+9y3CotXJopEK48njgAQm0dvyMB6j130C
CSlCDGv2D71PMvyeY8M1J67YOumzlkBqDDJP+8EJyD5MM0JSeT0a423BvmAxzoKwbNhcjEvK5F5X
fj2/DRULLt9QIxmrlVbXTTbcFSRyasFtvL2Qvh3yDdM7ceCW4RGRrpBwS6+nMuqHW+2zfZ07DMGH
qa4MPqNC2IrUcTEWbHJMIakeNf/pBNbHzhLeujzpjT3Q72c3ECZyYsmmlna7aUYlvBw7SPZh3Z3H
eV2TrABem/FrR040dboMhKC9jkv+dZp4yL5MSRtl1jd2QGzRFW40XUqSfpRfxjHBQYpIciLwJzJ6
LSvaY4m2pS8V6aC4JBboAUx8GnfR370p0P84aAMdFIgTr6CU174gRh2rP98Y1Q45Iibi5v/+h7KO
B7pM1AzFEq/+IfRnaPf47hZakg2lWau2HeoAddoy97pHBI1mi4ClNJpmaoah8LfzZzlknYHsrBpT
HbPo6hcUMIPHBgWkRLUpnXBCD8enxmGnSsuAb2Ht6sjNR8Iq694oy1PCZEliHSHPzt9fVEgJVVgQ
yZ7On+OPCHfyOMnc0gJya1RWXTvd/hs076irO/W/Upg4moxeSwsJIjQKXHHjuECD6m3mYrI6tAI4
lh9mP1BTuFad0/35NeH38no5JBCcYXyNAdpucZC28eMct+kpKWXuCGLXH7OslKmecs8rY8r+3kQM
cP0v/tPBeJS5X3gEITrjgxeNrmdNd0p8qVzTjqRBS8H+wn1Zsk4KBtTQiqqlJxlNquyQlwxdK178
1PPPORtxfSKUTz3ZMEzwD2mNV/RqILhdaHp0I0yt9dcJpxweDqpVlOkAfn1GlBpvhCgr/yAMaav7
DfVC3igmmHRbrd2oNQgc+Lmag8+rDYmv7BkP1MLE/hRuVrKcZQHm6vlAlwXLPW+AfnsnhSuxmQmf
FlC7HSQGHA7pVkQtTuyORDwW216bqU+FDOtBXmZH04Rr42rJxDEYvhDrAAb5oMNAHMzRiM+rZN+F
yBiTrwittBt/74fuImQn7DrR5AtWNaWo9DBs5tQpNtmEdhpXrPhpHtVC7aO8K1/3uiibQbCa9QBR
8q2gB0zM7PpUKGj6YOwjYrmLhZ4pZRKMhji8whxzNgSlQXmal/K0+Pw4n/9bu9yJFbGHXy8OPcAa
VjY4bnCVK+rmehi686hpl/0bcftb/MgnwNEJp5LcTX8muqWTedcjHXjqXNbIuyOQyhFjsG8/UeIq
2E41lBlB1nNnBqupO2A0KwAzWIIbHh9WBr8NTRvBczXPJ8Fs+FizU50iXcN604Sari2heKjy6J24
8bF5kc1a+a03GHNQvG2A5EfSlU54BxwxnJyEoB05

`pragma protect end_protected
endmodule
